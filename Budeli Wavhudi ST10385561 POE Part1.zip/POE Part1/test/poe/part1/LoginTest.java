/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package poe.part1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Wavhu Budeli
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        Account.userName = "kyl_1";
        Account.Password = "Ch&&sec@ke99";
        Account.loginName = "kyl_1";
        Account.loginPassword = "Ch&&sec@ke99";
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String userName = "kyl_1";
        boolean expResult = true;
        boolean result = Login.checkUserName(userName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String Password = "Ch&&sec@ke99";
        boolean expResult = true;
        boolean result = Login.checkPasswordComplexity(Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String userName = "";
        String Password = "";
        String expResult = "both ";
        String result = Login.registerUser();
        //assertEquals(expResult, result);
        assertTrue(result.contains(expResult));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String loginName = "kyl_1";
        String userName = "kyl_1";
        String loginPassword = "Ch&&sec@ke99";
        String Password = "Ch&&sec@ke99";
        boolean expResult = true;
        boolean result = Login.loginUser(loginName, userName, loginPassword, Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        String status = "";
        String name = "";
        String surname = "";
        String expResult = "Welcome"+name+" "+surname+" it is great to see you again";
        String result = Login.returnLoginStatus(status, name, surname);
        assertEquals(expResult, result);
        assertTrue(result.contains(expResult));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
