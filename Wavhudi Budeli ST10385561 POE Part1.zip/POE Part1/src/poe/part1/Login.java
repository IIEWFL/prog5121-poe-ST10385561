/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe.part1;

import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import static poe.part1.Account.Password;
import static poe.part1.Account.loginName;
import static poe.part1.Account.loginPassword;
import static poe.part1.Account.result;
import static poe.part1.Account.userName;

/**
 *
 * @author Wavhu Budeli
 */
public class Login {
public static String returningUsername,returningPassword;

    //code attribution
    //This method was taken from stack overflow
    //https://stackoverflow.com/questions/72061438/how-do-i-run-a-method-boolean-checkusername-this-method-ensures-that-any-use
    //Will
    //https://stackoverflow.com/users/1727416/will

    public static boolean checkUserName(String userName){
    return userName.length() <= 5 && userName.contains("_");
    }
    
    //code attribution 
    //This method was taken from stack overflow 
    //https://stackoverflow.com/questions/37454110/how-to-create-a-java-program-to-check-if-your-password-is-strong-or-not
    //ishmaelMakitla
    //https://stackoverflow.com/users/3193249/ishmaelmakitla
    
    public static boolean checkPasswordComplexity(String Password){
        return Password.length() >=8 && Password.matches(".*[A-Z].*") && Password.matches(".*[0-9].*") && Password.matches(".*?[" + Pattern.quote("!@#$%^&*()_-+=[]{};:'<>,.?|/")+ "].*");
         }
    
    public static String registerUser(){
            String result;
           
            if (!checkUserName(userName)){
                result = "unsuccessful";
                
            } else if (!checkPasswordComplexity(Password)){
                result = "unsuccesful";
            }else {
                    result =" both these conditions are met and you have successfully registered";
            }
            return result;
        }
    
    public static boolean loginUser(String loginName, String userName, String loginPassword, String Password){
        return loginName.equals(userName) && loginPassword.equals(Password);
    }
    
    public static String returnLoginStatus(String status, String name, String surname){
            if (!loginUser (loginName, userName, loginPassword, Password)){
                result = "userName or Password incorrect, please try again";
            }else{
                result = "Welcome"+name+" "+surname+" it is great to see you again";
            }
            return result;
           
        }
}
