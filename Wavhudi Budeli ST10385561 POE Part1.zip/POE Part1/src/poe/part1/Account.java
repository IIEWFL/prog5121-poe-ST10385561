/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe.part1;

import javax.swing.JOptionPane;

/**
 *
 * @author Wavhu Budeli
 */
public class Account {
    /**
     * @param args the command line arguments
     */
        static String name;
        static String surname;
        static String Password;
        static String userName;
        static String result = "";
        static String loginName = "";
        static String loginPassword = "";
        public static String returningUsername,returningPassword;
        
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        name = JOptionPane.showInputDialog(null, "Enter your name");
        surname = JOptionPane.showInputDialog(null, "Enter your surname");
        Password = JOptionPane.showInputDialog(null, "Enter your password");
        userName = JOptionPane.showInputDialog(null, "Enter your username");
        JOptionPane.showMessageDialog(null,"Your name is " + name + "Your surname is" + surname +"Your password is"+ Password+"Your username is"+userName+"");
        while (!Login.checkUserName(userName)){
            System.out.println(Login.registerUser());
            JOptionPane.showMessageDialog(null,"Enter you username again" );
            userName = JOptionPane.showInputDialog(null, "Enter your username");
        }
        while(!Login.checkPasswordComplexity(Password)){
            System.out.println(Login.registerUser());
            System.out.println("Your password is incorrect. try again");
            Password = JOptionPane.showInputDialog(null, "Enter your password");
        }
        
        loginName = JOptionPane.showInputDialog(null, "Enter your name ");
        loginPassword = JOptionPane.showInputDialog(null, "Enter your password");
        JOptionPane.showMessageDialog(null,"Your loginName is " + loginName + "loginPassword is" + loginPassword+"");
        while (!Login.loginUser(loginName, userName, loginPassword, Password)){
            loginName = JOptionPane.showInputDialog(null, "Enter your loginname ");
            loginPassword = JOptionPane.showInputDialog(null, "Enter your loginpassword");
        }
        System.out.println(Login.returnLoginStatus(result, name, surname));
    }
    
    
}
